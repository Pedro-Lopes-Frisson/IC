clear all;
close all;
clc;

MID = readmatrix('MID.txt');
SIDE = readmatrix('SIDE.txt');

samples_MID = MID(:,1);
occ_MID = MID(:,2);

samples_SIDE = SIDE(:,1);
occ_SIDE = SIDE(:,2);

figure(1)
bar(samples_MID,occ_MID)
title('MID')
xlabel('Samples')
ylabel('Ocorrências')


figure(2)
bar(samples_SIDE,occ_SIDE,'r')
title('SIDE')
xlabel('Samples')
ylabel('Ocorrências')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tamanhoBS1024 = readmatrix('tamanhoBS1024.txt');
tamanhoBS1024_y = tamanhoBS1024(:,1);
tamanhoBS1024_x = tamanhoBS1024(:,2);

tamanhoBS512 = readmatrix('tamanhoBS512.txt');
tamanhoBS512_y = tamanhoBS512(:,1);
tamanhoBS512_x = tamanhoBS512(:,2);

tamanhoBS256 = readmatrix('tamanhoBS256.txt');
tamanhoBS256_y = tamanhoBS256(:,1);
tamanhoBS256_x = tamanhoBS256(:,2);

tamanhoBS128 = readmatrix('tamanhoBS128.txt');
tamanhoBS128_y = tamanhoBS128(:,1);
tamanhoBS128_x = tamanhoBS128(:,2);

tamanhoBS64 = readmatrix('tamanhoBS64.txt');
tamanhoBS64_y = tamanhoBS64(:,1);
tamanhoBS64_x = tamanhoBS64(:,2);

tamanhoBS32 = readmatrix('tamanhoBS32.txt');
tamanhoBS32_y = tamanhoBS32(:,1);
tamanhoBS32_x = tamanhoBS32(:,2);

tamanhoBS16 = readmatrix('tamanhoBS16.txt');
tamanhoBS16_y = tamanhoBS16(:,1);
tamanhoBS16_x = tamanhoBS16(:,2);

tamanhoBS8 = readmatrix('tamanhoBS8.txt');
tamanhoBS8_y = tamanhoBS8(:,1);
tamanhoBS8_x = tamanhoBS8(:,2);

figure(3)
plot(tamanhoBS1024_x,tamanhoBS1024_y,'o-k')
hold on
plot(tamanhoBS512_x,tamanhoBS512_y,'o-c')
hold on
plot(tamanhoBS256_x,tamanhoBS256_y,'o-b')
hold on
plot(tamanhoBS128_x,tamanhoBS128_y,'o-r')
hold on
plot(tamanhoBS64_x,tamanhoBS64_y,'o-g')
hold on
plot(tamanhoBS32_x,tamanhoBS32_y,'o-y')
hold on
plot(tamanhoBS16_x,tamanhoBS16_y,'o-m')
hold on
plot(tamanhoBS8_x,tamanhoBS8_y,'o-')
xlabel('Fraction of kept low Frequencies')
ylabel('Nº of Bytes (Encoded File Size)')
legend('bs1024','bs512','bs256','bs128','bs64','bs32','bs16','bs8','Location','northwest')






